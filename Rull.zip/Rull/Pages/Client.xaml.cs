﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Rull.Entities; //Добавляем папку с моделью БД
using Rull.Windows; //Добавляем папку с окнами проекта
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Rull.Pages
{
    /// <summary>
    /// Логика взаимодействия для Client.xaml
    /// </summary>
    public partial class Client : Page
    {
        User user = new User(); //Создаём пустой объект пользователя
        List<Product> orderProducts = new List<Product>();
        private void btnAddProduct_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            orderProducts.Add(LViewProduct.SelectedItem as Product);
            if (orderProducts.Count > 0)
            {
                btnOrder.Visibility = Visibility.Visible;
            }
        }
        public Client(User currentUser)
        {
            InitializeComponent();
            var product = RulEntities.GetContext().Product.ToList(); //Обращаемся к таблице "Товары"
            LViewProduct.ItemsSource = product; //Передаём таблицу в лист
            DataContext = this; //Привязываем контекст данных к коду, чтобы обратиться к массивам
            txtAllAmount.Text = product.Count().ToString(); //Передаём кол-во всех записей из таблицы
            user = currentUser; //Передаём конкретного пользователя
            UpdateData(); //Вызываем метод
            User();
        }
        private void User()
        {
            if (user != null)
                txtFullName.Text = user.UserSurname.ToString() + user.UserName.ToString() + " " + user.UserPatronymic.ToString();
            else
                txtFullName.Text = "Гость";
        }
        public string[] SortingList { get; set; } =
            {
            "Без сортировки",
            "Стоимость по возрастанию",
            "Стоимость по убыванию"
            };
        public string[] FilterList { get; set; } =
           {
            "Все диапазоны",
            "0%-9,99%",
            "10%-14,99%",
            "15% и более"
            };
        private void UpdateData()
        {
            var result = RulEntities.GetContext().Product.ToList(); //Вводим переменную, которая принимает данные из таблицы товаров
            /*Реализация сортировки с помощью запросов на сортировку по возрастанию и убыванию цены*/
            if (cmbSorting.SelectedIndex == 1)
                result = result.OrderBy(p => p.ProductCost).ToList();
            if (cmbSorting.SelectedIndex == 2)
                result = result.OrderByDescending(p => p.ProductCost).ToList();
            /*Реализация фильтрации с помощью запросов на выборку по условиям задания*/
            if (cmbFilter.SelectedIndex == 1)
                result = result.Where(p => p.ProductDiscountAmount >= 0 && p.ProductDiscountAmount < 10).ToList();
            if (cmbFilter.SelectedIndex == 2)
                result = result.Where(p => p.ProductDiscountAmount >= 10 && p.ProductDiscountAmount < 15).ToList();
            if (cmbFilter.SelectedIndex == 3)
                result = result.Where(p => p.ProductDiscountAmount >= 15).ToList();
            /*Реализация поиска*/
            result = result.Where(p => p.ProductName.ToLower().Contains(txtSearch.Text.ToLower())).ToList();
            LViewProduct.ItemsSource = result; //Передаём результат в ListView
            /*Передаём кол-во записей после применения поиска, сортировки, фильтрации */
            txtResultAmount.Text = result.Count().ToString();        
        }

        private void cmbSorting_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateData(); //Вызываем метод
        }
        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateData(); //Вызываем метод
        }
        private void cmbFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateData(); //Вызываем метод
        }

        private void btnOrder_Click(object sender, RoutedEventArgs e)
        {
            OrderWindow order = new OrderWindow(orderProducts, user);
            order.ShowDialog();
        }
        private void LViewProduct_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
