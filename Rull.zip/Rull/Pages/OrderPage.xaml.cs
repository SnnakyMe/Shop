﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Rull.Entities;


namespace Rull.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrderPage.xaml
    /// </summary>
    public partial class OrderPage : Page
    {
        /*Создаём устой лист, к которому можно будет обращаться во всех методах */
        List<Product> productList = new List<Product>(); 
        public OrderPage(List<Product> products, User user)
        {
            InitializeComponent();
            DataContext = this; //Привязываем контекст данных к коду
            productList = products; //Передаём список  товрами в пустой лист
            LViewOrder.ItemsSource= productList; //Выводимсписок выбранных товаров в ListView
            //Выводим в ComboBox список пунктов выдачи
            cmbPickupPoint.ItemsSource = RulEntities.GetContext().PickupPoint.ToList();
            if (user != null)
                txtUser.Text = user.UserSurname.ToString() + user.UserName.ToString() + " " + user.UserPatronymic.ToString();
            //Добавляем проверку на пользователя, если пользователь есть в системе, выводим в TextBox ФИО
        }
        public string Total
        {
            get
            {
                var total = productList.Sum(p => Convert.ToDouble(p.ProductCost) - Convert.ToDouble(p.ProductCost) * Convert.ToDouble(p.ProductDiscountAmount / 100.00));
                return total.ToString();
            }
        }

        private void btnDeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите удалить этот элемент?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                productList.Remove(LViewOrder.SelectedItem as Product);

        }

        private void btnOrderSave_Click(object sender, RoutedEventArgs e)
        {
            /*Производим поиск товаров по артикулу, добавляю каждый отдельным элементом массива */
            var productArticle = productList.Select(p => p.ProductArticleNumber).ToArray();
            var random = new Random(); //Для получения случайного числа в код получения
            var date = DateTime.Now; //Переменная для хранения сегодняшней даты
            /*Проверка по заданию*/
            if (productList.Any(p =>p.ProductQuantityInStock < 3))
                date = date.AddDays(6);
            else date = date.AddDays(3);

            if (cmbPickupPoint.SelectedItem == null)
            {
                MessageBox.Show("Выберите пункт выдачи!", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            try
            {
                Order newOrder = new Order()
                {
                    OrderStatus = "Новый",
                    OrderDate = DateTime.Now,
                    OrderPickupPoint = cmbPickupPoint.SelectedIndex + 1, //Добавляем данные в пустой объукт заказа
                    OrderDeliveryDate = date,
                    ReceiptCode = random.Next(100, 1000),
                    ClientFullName = txtUser.Text,

                };
                RulEntities.GetContext().Order.Add(newOrder); //Передаём добавленные данные в таблицу "Заказ"
                for (int i = 0; i < productArticle.Count(); i++)
                {
                    OrderProduct newOrderProduct = new OrderProduct()
                    {
                       OrderID = newOrder.OrderID,
                       ProductArticleNumber = productArticle[i], //В пустой объект добавляем данные
                        ProductCount = 1
                    };
                    /*Передаём добвленные данные в таблицу связи между таблицами "Товар" и "Заказ"*/
                    RulEntities.GetContext().OrderProduct.Add(newOrderProduct);
                }
                RulEntities.GetContext().SaveChanges(); //Сохраняем добавленные в БД записи
                MessageBox.Show("Заказ оформлен!", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                NavigationService.Navigate(new OrderTicketPage(newOrder, productList)); //Переходим на страницу талона заказа   
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString()); //Выводим ошибки если они есть
            }

        }
    }

}
