﻿using Rull.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Rull.Pages
{
    /// <summary>
    /// Логика взаимодействия для Autho.xaml
    /// </summary>
    
    public partial class Autho : Page
    {
        int countUnsuccessful = 0; //Количество неверных попыток входа
        public Autho()
        {
            InitializeComponent();
            /*Скрываем надпись и поле для ввода капчи*/
            txtCaptcha.Visibility = Visibility.Hidden; 
            textBlockCaptcha.Visibility = Visibility.Hidden;
        }
        private void btnEnterGuest_Click(object sender, RoutedEventArgs e)
        {
            /*Переход на страницу клиента для неавторизованного пользователя*/
            NavigationService.Navigate(new Client(null)); 
        }

        private void btnEnter_Click(object sender, RoutedEventArgs e)
        {
            //Объявляем переменную, в которую будут записываться значения с TextBlock'a логина
            string login = txtLogin.Text.Trim();
            //Объявляем переменную, в которую будут записываться значения с TextBlock'a пароля
            string password = txtPassword.Text.Trim();

            User user = new User();
            
            user = RulEntities.GetContext().User.Where
                (p => p.UserLogin == login && p.UserPassword == password).FirstOrDefault();
            int userCount = RulEntities.GetContext().User.Where
                (p => p.UserLogin == login && p.UserPassword == password).Count();
            if (countUnsuccessful < 1)
            {
                if (userCount > 0)
                {
                    MessageBox.Show("Вы пошли под: " + user.Role.RoleName.ToString());
                    LoadForm(user.Role.RoleName.ToString(), user);
                }
                else
                {
                    MessageBox.Show("Вы ввели неверно логин или пароль");
                    countUnsuccessful++;
                    if (countUnsuccessful == 1) //Если есть неверная попытка генерируем Капчу
                        GeneratedCapctha();
                }
            }
            else
            {
                if (userCount > 0 && textBlockCaptcha.Text == txtCaptcha.Text)
                {
                    MessageBox.Show("Вы вошли под " + user.Role.RoleName.ToString());
                    LoadForm(user.Role.RoleName.ToString(),user);
                }
                else
                {
                    MessageBox.Show("Введите данные заново!");
                }
            }
            
        }
        private void GeneratedCapctha()
        {
            txtCaptcha.Visibility = Visibility.Visible; //Показывает надпись
            textBlockCaptcha.Visibility = Visibility.Visible; //и поле ввода для капчи
            Random random = new Random();
            int randnNum = random.Next(1,4); //генерируем случайное число от 1 до 3
            textBlockCaptcha.TextDecorations = TextDecorations.Strikethrough;
            switch (randnNum)
            {
                case 1: textBlockCaptcha.Text = "ju2st8cbs"; break;
                case 2: textBlockCaptcha.Text = "in0k2cl5a"; break;
                case 3: textBlockCaptcha.Text = "u0zGk95ty"; break;
            }    
        }
        private void LoadForm(string _role, User user)
        {
            switch (_role)
            {
                case "Клиент": 
                    NavigationService.Navigate(new Client(user)); //Если роль пользователя "Клиент"
                    break;
                case "Менеджер":
                     NavigationService.Navigate(new Client(user)); break;
                case "Администратор":
                    NavigationService.Navigate(new Admin(user)); break; //Если пользователь Админ
            }
        }
    }
}
