﻿Class Application

    ' События приложения, например, Startup, Exit и DispatcherUnhandledException,
    ' можно обрабатывать в данном файле.

End Class
